#include <tls.h>

#include "tls-macros.h"

COMMON_INT_DEF(bar);
