#include <stdio.h>

int
baz (int x)
{
  puts ("in baz");
  return x * 4;
}
