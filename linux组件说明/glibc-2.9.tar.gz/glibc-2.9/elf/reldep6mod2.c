extern int foo (void);

void *foop = (void *) foo;
