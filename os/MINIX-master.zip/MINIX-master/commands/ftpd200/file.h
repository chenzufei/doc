/* file.h Copyright 1992-2000 by Michael Temari All Rights Reserved
 *
 * This file is part of ftpd.
 *
 *
 * 01/25/96 Initial Release	Michael Temari, <Michael@TemWare.Com>
 */

_PROTOTYPE(int doALLO, (char *buff));
_PROTOTYPE(int doAPPE, (char *buff));
_PROTOTYPE(int doCDUP, (char *buff));
_PROTOTYPE(int doCWD,  (char *buff));
_PROTOTYPE(int doDELE, (char *buff));
_PROTOTYPE(int doLIST, (char *buff));
_PROTOTYPE(int doMDTM, (char *buff));
_PROTOTYPE(int doMODE, (char *buff));
_PROTOTYPE(int doMKD,  (char *buff));
_PROTOTYPE(int doNLST, (char *buff));
_PROTOTYPE(int doPWD,  (char *buff));
_PROTOTYPE(int doREST, (char *buff));
_PROTOTYPE(int doRETR, (char *buff));
_PROTOTYPE(int doRMD,  (char *buff));
_PROTOTYPE(int doRNFR, (char *buff));
_PROTOTYPE(int doRNTO, (char *buff));
_PROTOTYPE(int doSITE, (char *buff));
_PROTOTYPE(int doSIZE, (char *buff));
_PROTOTYPE(int doSTAT, (char *buff));
_PROTOTYPE(int doSTOR, (char *buff));
_PROTOTYPE(int doSTOU, (char *buff));
_PROTOTYPE(int doSTRU, (char *buff));
_PROTOTYPE(int doSYST, (char *buff));
_PROTOTYPE(int doTYPE, (char *buff));
