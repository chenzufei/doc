/* libyywrap - flex run-time support library "yywrap" function */

/* $Header$ */

int yywrap()
	{
	return 1;
	}
