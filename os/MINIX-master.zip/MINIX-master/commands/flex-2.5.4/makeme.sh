CC=cc /bin/sh ./configure --prefix=/usr/local && bigmake all
