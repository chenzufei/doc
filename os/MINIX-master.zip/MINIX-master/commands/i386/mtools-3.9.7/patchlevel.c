const char *mversion="3.9.7";
const char *mdate = "1 jun 2000";
