/* other.h
 *
 * This file is part of ftp.
 *
 *
 * 01/25/96 Initial Release	Michael Temari, <temari@ix.netcom.com>
 */

_PROTOTYPE(void FTPinit, (void));
_PROTOTYPE(int DOpass, (void));
_PROTOTYPE(int DOuser, (void));
_PROTOTYPE(int DOnoop, (void));
_PROTOTYPE(int DOpassive, (void));
_PROTOTYPE(int DOsyst, (void));
_PROTOTYPE(int DOremotehelp, (void));
_PROTOTYPE(int DOquote, (void));
_PROTOTYPE(int DOsite, (void));
