/* local.h
 *
 * This file is part of ftp.
 *
 *
 * 01/25/96 Initial Release	Michael Temari, <temari@ix.netcom.com>
 */

_PROTOTYPE(int DOlpwd, (void));
_PROTOTYPE(int DOlcd, (void));
_PROTOTYPE(int DOlmkdir, (void));
_PROTOTYPE(int DOlrmdir, (void));
_PROTOTYPE(int DOllist, (void));
_PROTOTYPE(int DOlnlst, (void));
_PROTOTYPE(int DOlshell, (void));
