Minix 1

Andy Tanenbaum first released MINIX 1 in 1987 as an appendix to the book, Operating Systems: Design and Implementation
