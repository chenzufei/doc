/* sync - flush the file system buffers.  Author: Andy Tanenbaum */

main() {sync();}	/* First prize in shortest useful program contest. */
