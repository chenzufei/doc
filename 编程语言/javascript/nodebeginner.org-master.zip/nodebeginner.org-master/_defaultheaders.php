<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=0.5, minimum-scale=0.5, maximum-scale=1"/>
<link rel="icon" href="favicon.png" type="image/png" />
