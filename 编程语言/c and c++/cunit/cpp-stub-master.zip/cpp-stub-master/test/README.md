
**Windows msvc use**
- nmake -f Makefile.win32  (x86 Native Tools Command Prompt for VS 2019)
- nmake -f Makefile.win64  (x64 Native Tools Command Prompt for VS 2019)

**Linux gcc use**
- make -f Makefile.linux32.gcc
- make -f Makefile.linux64.gcc

**Linux clang use**

- make -f Makefile.linux32.clang
- make -f Makefile.linux64.clang
