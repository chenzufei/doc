#pragma once

#include "obj.hpp"


bool check_obj(Obj &obj);
