#include <iostream>
#include "obj_operations.hpp"


int main(int argc, char *argv[])
{
    Obj obj;
    check_obj(obj);
    return 0;
}
