# Sample catch2 test project

This is a sample project using the Catch2 framework with
some examples of a few tests.

The framework is well documented at:
 * [Catch2](https://github.com/catchorg/Catch2/tree/master/docs)



