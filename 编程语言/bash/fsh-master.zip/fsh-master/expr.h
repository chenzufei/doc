#ifndef __EXPR_H__
#define __EXPR_H__

/* evaluate a constant expression, result is stored in res */
void eval_expr (char *str, int *res);


#endif

