#include "lexan.h"

/* get next token from string str, starting at index start */
int get_next_token (unsigned char *str, unsigned int start, struct lextoken_s *result)
{
}


